# -*- coding: utf-8 -*-
# reporter.py

"""This module provides the Auto report tool entry-point script."""
from auto_report.app import main


if __name__ == '__main__':
    main()